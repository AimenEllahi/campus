import "./App.css";
import Campus from "./Components/3D/Index";

function App() {
  return (
    <div>
      <Campus />
    </div>
  );
}

export default App;
